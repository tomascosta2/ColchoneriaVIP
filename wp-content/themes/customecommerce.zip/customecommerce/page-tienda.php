<?php get_header(); ?>

<div class="container">
	<?php echo do_shortcode('[products columns="4" category="hoodies, tshirts" cat_operator="OR"]') ?>
</div>

<?php get_footer(); ?>