<?php get_header(); ?>

<div class="container">
	<div class="tcp-homebanner">
		
	</div>
</div>

<?php get_footer(); ?>