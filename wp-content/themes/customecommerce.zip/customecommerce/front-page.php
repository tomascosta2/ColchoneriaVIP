<?php get_header(); ?>

home content

<?php get_footer(); ?>